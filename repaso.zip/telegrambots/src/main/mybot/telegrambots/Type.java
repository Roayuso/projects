package telegrambots;

public enum Type {
	TYPE_1("Tipo 1"),
	TYPE_2("Tipo 2"),
	TYPE_3("Tipo 3");
	
	String name;
	
	Type(String name){
		this.name = name;
	}
	
	String showName() {
		return this.name;
	}
	
}
