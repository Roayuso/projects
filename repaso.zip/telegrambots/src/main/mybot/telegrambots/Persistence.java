package telegrambots;

import java.util.List;

public class Persistence {
	
	private int state;
	private List<Element> elementList;
	private Element element;
	private String dictionary;
	private String te;
	private String nai;
	private String ta;

	public Persistence() {
		this.state = 99;
		this.elementList = null;
		this.element = null;
		this.dictionary = "";
		this.te = "";
		this.nai = "";
		this.ta = "";
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public List<Element> getElementList() {
		return elementList;
	}

	public void setElementList(List<Element> elementList) {
		this.elementList = elementList;
	}

	public Element getElement() {
		return element;
	}

	public void setElement(Element e) {
		this.element = e;
	}

	public String getDictionary() {
		return dictionary;
	}

	public void setDictionary(String dictionary) {
		this.dictionary = dictionary;
	}

	public String getTe() {
		return te;
	}

	public void setTe(String te) {
		this.te = te;
	}

	public String getNai() {
		return nai;
	}

	public void setNai(String nai) {
		this.nai = nai;
	}

	public String getTa() {
		return ta;
	}

	public void setTa(String ta) {
		this.ta = ta;
	}

}
