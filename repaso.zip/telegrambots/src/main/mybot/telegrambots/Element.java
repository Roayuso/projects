package telegrambots;

public class Element {

	private Type type;
	private String kanjiForm;
	private String masuForm;
	private String dictionaryForm;
	private String teForm;
	private String naiForm;
	private String taForm;
	private String meaning;
	
	public Element(Type type, String kanjiForm, String masuForm, String dictionaryForm, String teForm, String naiForm,
			String taForm, String meaning) {
		this.type = type;
		this.kanjiForm = kanjiForm;
		this.masuForm = masuForm;
		this.dictionaryForm = dictionaryForm;
		this.teForm = teForm;
		this.naiForm = naiForm;
		this.taForm = taForm;
		this.meaning = meaning;
	}

	public Type getType() {
		return type;
	}

	public String getKanjiForm() {
		return kanjiForm;
	}

	public String getMasuForm() {
		return masuForm;
	}

	public String getDictionaryForm() {
		return dictionaryForm;
	}

	public String getTeForm() {
		return teForm;
	}

	public String getNaiForm() {
		return naiForm;
	}

	public String getTaForm() {
		return taForm;
	}

	public String getMeaning() {
		return meaning;
	}
}
