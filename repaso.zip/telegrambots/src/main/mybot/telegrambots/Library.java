package telegrambots;

import java.util.ArrayList;
import java.util.List;

public class Library {
	
	public static List<Element> populateLibrary() {
		
		List<Element> list = new ArrayList<Element>();
		list.add(new Element(Type.TYPE_1, "行きます", "いきます", "いく", "いって", "いかない", "いった", "ir"));
		list.add(new Element(Type.TYPE_2, "食べます", "たべます", "たべる", "たべて", "たべない", "たべた", "comer"));
		return list;
	}
}
