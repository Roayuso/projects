package telegrambots;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

public class MyAmazingBot extends TelegramLongPollingBot{

	public static Map<Long, Persistence> persistenceMap = new HashMap<>();

	@Override
	public void onUpdateReceived(Update update) {

		Long userId = update.getMessage().getChat().getId();

		if(!persistenceMap.containsKey(userId)) {
			persistenceMap.put(userId, new Persistence());
		}

		if (update.hasMessage() && update.getMessage().hasText()) {
			String text = "";

			if(persistenceMap.get(userId).getState() == 5) {
				String input = update.getMessage().getText();
				if(input.equals("reset"))
					persistenceMap.get(userId).setState(99);
				else
					persistenceMap.get(userId).setState(0);
			}


			if(persistenceMap.get(userId).getState() == 99) {
				persistenceMap.get(userId).setElementList(Library.populateLibrary());
				persistenceMap.get(userId).setState(0);
			}

			if(persistenceMap.get(userId).getState() == 0) {
				int i = persistenceMap.get(userId).getElementList().size()-1==0
						?0
								:new Random().nextInt(persistenceMap.get(userId).getElementList().size()-1);
				persistenceMap.get(userId).setElement(persistenceMap.get(userId).getElementList().get(i));
				persistenceMap.get(userId).getElementList().remove(i);

				text+=("+------|-----------------------\r\n");
				text+=("| かんじ | " + persistenceMap.get(userId).getElement().getKanjiForm() + "\r\n");
				text+=("| ます    | " + persistenceMap.get(userId).getElement().getMasuForm() + "\r\n");
				text+=("| じしょ  | " + "_________\r\n");
				text+=("| て       | \r\n");
				text+=("| ない    | \r\n");
				text+=("| た       | \r\n");
				text+=("| esp | " + persistenceMap.get(userId).getElement().getMeaning()+"\r\n");
				text+=("+------------------------------\r\n");

				persistenceMap.get(userId).setState(1);
			}

			else if(persistenceMap.get(userId).getState() == 1) {
				persistenceMap.get(userId).setDictionary(update.getMessage().getText());

				text+=("+------------------------------\r\n");
				text+=("| かんじ | " + persistenceMap.get(userId).getElement().getKanjiForm() + "\r\n");
				text+=("| ます    | " + persistenceMap.get(userId).getElement().getMasuForm() + "\r\n");
				text+=("| じしょ  | " + persistenceMap.get(userId).getDictionary() + "\r\n");
				text+=("| て       | " + "_________\r\n");
				text+=("| ない    | \r\n");
				text+=("| た       | \r\n");
				text+=("| esp | " + persistenceMap.get(userId).getElement().getMeaning() + "\r\n");
				text+=("+------|-----------------------\r\n");

				persistenceMap.get(userId).setState(2);
			}

			else if(persistenceMap.get(userId).getState() == 2) {
				persistenceMap.get(userId).setTe(update.getMessage().getText());

				text+=("+------------------------------\r\n");
				text+=("| かんじ | " + persistenceMap.get(userId).getElement().getKanjiForm() + "\r\n");
				text+=("| ます    | " + persistenceMap.get(userId).getElement().getMasuForm() + "\r\n");
				text+=("| じしょ  | " + persistenceMap.get(userId).getDictionary() + "\r\n");
				text+=("| て       | " + persistenceMap.get(userId).getTe() + "\r\n");
				text+=("| ない    | "+ "_________\r\n");
				text+=("| た       | \r\n");
				text+=("| esp | " + persistenceMap.get(userId).getElement().getMeaning() + "\r\n");
				text+=("+------|-----------------------\r\n");

				persistenceMap.get(userId).setState(3);
			}

			else if(persistenceMap.get(userId).getState() == 3) {
				persistenceMap.get(userId).setNai(update.getMessage().getText());

				text+=("+------------------------------\r\n");
				text+=("| かんじ | " + persistenceMap.get(userId).getElement().getKanjiForm() + "\r\n");
				text+=("| ます    | " + persistenceMap.get(userId).getElement().getMasuForm() + "\r\n");
				text+=("| じしょ  | " + persistenceMap.get(userId).getDictionary() + "\r\n");
				text+=("| て       | " + persistenceMap.get(userId).getTe() + "\r\n");
				text+=("| ない    | "+ persistenceMap.get(userId).getNai() + "\r\n");
				text+=("| た       | "+ "_________\r\n");
				text+=("| esp | " + persistenceMap.get(userId).getElement().getMeaning() + "\r\n");
				text+=("+------|-----------------------\r\n");

				persistenceMap.get(userId).setState(4);
			}

			else if(persistenceMap.get(userId).getState() == 4) {
				persistenceMap.get(userId).setTa(update.getMessage().getText());

				boolean errors = false;
				boolean errorDictionary = false;
				boolean errorTe = false;
				boolean errorNai = false;
				boolean errorTa = false;

				if(!persistenceMap.get(userId).getDictionary()
						.equals(persistenceMap.get(userId).getElement().getDictionaryForm())) {
					errors = true;
					errorDictionary = true;
					text+=("Error en forma diccionario\r\n");
				}
				if(!persistenceMap.get(userId).getTe()
						.equals(persistenceMap.get(userId).getElement().getTeForm())) {
					errors = true;
					errorTe = true;
					text+=("Error en forma te\r\n");
				}
				if(!persistenceMap.get(userId).getNai()
						.equals(persistenceMap.get(userId).getElement().getNaiForm())) {
					errors = true;
					errorNai = true;
					text+=("Error en forma nai\r\n");
				}
				if(!persistenceMap.get(userId).getTa()
						.equals(persistenceMap.get(userId).getElement().getTaForm())) {
					errors = true;
					errorTa = true;
					text+=("Error en forma ta\r\n");
				}
				if(!errors) {
					text+=("Todo correcto.\r\n");
				}
				text+=("+------|----Real-----|----Tuya----\r\n");
				text+=("| かんじ | " + persistenceMap.get(userId).getElement().getKanjiForm() + "\r\n");
				text+=("| ます    | " + persistenceMap.get(userId).getElement().getMasuForm()+ "\r\n");
				text+=("| じしょ  | " + persistenceMap.get(userId).getElement().getDictionaryForm()
						+ chechElement(errorDictionary, persistenceMap.get(userId).getDictionary())+ "\r\n");
				text+=("| て       | " + persistenceMap.get(userId).getElement().getTeForm() 
						+ chechElement(errorTe, persistenceMap.get(userId).getTe())+ "\r\n");
				text+=("| ない    | " + persistenceMap.get(userId).getElement().getNaiForm() 
						+ chechElement(errorNai, persistenceMap.get(userId).getNai())+ "\r\n");
				text+=("| た       | " + persistenceMap.get(userId).getElement().getTaForm() 
						+ chechElement(errorTa, persistenceMap.get(userId).getTa())+ "\r\n");
				text+=("| esp | " + persistenceMap.get(userId).getElement().getMeaning()+ "\r\n");
				text+=("+------------------------------\r\n");

				if(persistenceMap.get(userId).getElementList().isEmpty()) {
					text += "Has acabado el listado. Envia lo que quieras para cargarlo de nuevo";
					persistenceMap.get(userId).setState(99);
				}
				else {
					persistenceMap.get(userId).setState(5);
					text += "Envia lo que sea para otra nueva o 'reset' para resetear la lista";
				}
			}   			    	

			SendMessage message = new SendMessage() // Create a SendMessage object with mandatory fields
					.setChatId(update.getMessage().getChatId())
					.setText(text);
			try {
				execute(message); // Call method to send the message
			} catch (TelegramApiException e) {
				e.printStackTrace();
			}
		}		
	}


	private static String chechElement(boolean check, String input) {
		if(!check)
			return "";
		return "       | " + input;
	}

	@Override
	public String getBotUsername() {
		return "JapanVerbsBot";
	}

	@Override
	public String getBotToken() {
		return "971785916:AAHEMd_SMsdimKUrRkgHS5Y1Y1kdSuhpRGw";
	}
}
